<div class="mkdf-vss-ms-section" <?php echo foton_mikado_get_inline_attrs($content_data); ?> <?php foton_mikado_inline_style($content_style);?>>
	<?php echo foton_mikado_get_module_part($content); ?>
</div>