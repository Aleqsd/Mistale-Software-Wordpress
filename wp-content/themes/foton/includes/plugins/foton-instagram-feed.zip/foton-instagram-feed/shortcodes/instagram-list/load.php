<?php

include_once FOTON_INSTAGRAM_SHORTCODES_PATH . '/instagram-list/functions.php';
include_once FOTON_INSTAGRAM_SHORTCODES_PATH . '/instagram-list/instagram-list.php';